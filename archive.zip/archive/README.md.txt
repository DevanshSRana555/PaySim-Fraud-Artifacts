# PaySim Fraud Detection Artifacts

This repository contains trained machine learning artifacts for the paper:

"A Leakage-Free, Prior-Shift-Corrected Benchmark of Machine Learning Algorithms for Imbalanced Fraud Detection"

Contents:
- Random Forest model
- XGBoost model
- Logistic Regression model
- Threshold optimization outputs
- Calibration artifacts
- Evaluation figures

Environment:
Python: 3.12.12
scikit-learn: 1.6.1
xgboost: 3.2.0
imbalanced-learn: 0.14.1
pandas: 2.3.3
numpy: 2.0.2